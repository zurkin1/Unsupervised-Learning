import itertools
import logging
import math
import random
import sys
import time
from collections import defaultdict
from pathlib import Path
import numpy as np
import torch
from apex import amp
from torch import nn
from dataset import *
from model import ModelAndLoss


def setup_determinism(args):
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    random.seed(args.seed)


@torch.no_grad()
def infer(args, model, loader):
    """Infer and return prediction in dictionary formatted {sample_id: logits}"""

    if not len(loader):
        return {}
    res = {}

    model.eval()
    tic = time.time()
    for i, (X, S, I, *_) in enumerate(loader):
        if args.cuda:
            X = X.cuda()
            S = S.cuda()

        Xs = tta(args, X) if args.tta else [X]
        ys = [model.eval_forward(X, S) for X in Xs]
        y = torch.stack(ys).mean(0).cpu()

        for j in range(len(I)):
            assert I[j].item() not in res
            res[I[j].item()] = y[j].numpy()

        if (i + 1) % args.disp_batches == 0:
            logging.info('Infer Iter: {:4d}  ->  speed: {:6.1f}'.format(
                i + 1, args.disp_batches * args.batch_size / (time.time() - tic)))
            tic = time.time()

    return res


def predict(args, model):
    """Entrypoint for predict mode"""

    test_loader = get_test_loader(args)
    train_loader, val_loader = get_train_val_loader(args, predict=True)

    model = amp.initialize(model, opt_level='O1')

    logging.info('Starting prediction')

    output = {}
    for k, loader in [('test', test_loader),
                      ('val', val_loader)]:
        output[k] = {}
        res = infer(args, model, loader)

        for i, v in res.items():
            d = loader.data[i]
            name = '{}_{}_{}'.format(d[0], d[1], d[2])
            if name not in output[k]:
                output[k][name] = []
            output[k][name].append(v)

    logging.info('Saving predictions to {}'.format(args.load + '.output' + args.pred_suffix))
    with open(args.load + '.output' + args.pred_suffix, 'wb') as file:
        pickle.dump(output, file)


def score(args, model, loader):
    """Return accuracy of the model on validation set"""

    logging.info('Starting validation')

    res = infer(args, model, loader)

    cell_type_c = np.array([0, 0, 0, 0])  # number of examples for given cell type
    cell_type_s = np.array([0, 0, 0, 0])  # number of correctly classified examples for given cell type
    for i, v in res.items():
        d = loader.data[i]
        r = v[:loader.treatment_classes].argmax() == d[-1]

        ser = loader.cell_types.index(d[4])
        cell_type_c[ser] += 1
        cell_type_s[ser] += r

    acc = (cell_type_s.sum() / cell_type_c.sum()).item() if cell_type_c.sum() != 0 else 0
    logging.info('Eval: acc: {} ({})'.format(cell_type_s / cell_type_c, acc))
    return acc


def get_learning_rate(args, epoch):
    assert len(args.lr[1][1::2]) + 1 == len(args.lr[1][::2])
    for start, end, lr, next_lr in zip([0] + args.lr[1][1::2],
                                       args.lr[1][1::2] + [args.epochs],
                                       args.lr[1][::2],
                                       args.lr[1][2::2] + [0]):
        if start <= epoch < end:
            if args.lr[0] == 'cosine':
                return lr * (math.cos((epoch - start) / (end - start) * math.pi) + 1) / 2
            elif args.lr[0] == 'const':
                return lr
            else:
                assert 0
    assert 0

@torch.no_grad()
def smooth_label(args, Y):
    nY = nn.functional.one_hot(Y, args.classes).float()
    nY += args.label_smoothing / (args.classes - 1)
    nY[range(Y.size(0)), Y] -= args.label_smoothing / (args.classes - 1) + args.label_smoothing
    return nY

@torch.no_grad()
def transform_input(args, X, S, Y):
    """Apply mixup, cutmix, and label-smoothing"""

    Y = smooth_label(args, Y)

    if args.mixup != 0 or args.cutmix != 0:
        if args.cuda:
            perm = torch.randperm(args.batch_size).cuda()
        else:
            perm = torch.randperm(args.batch_size)

    if args.mixup != 0:
        if args.cuda:
            coeffs = torch.tensor(np.random.beta(args.mixup, args.mixup, args.batch_size), dtype=torch.float32).cuda()
        else:
            coeffs = torch.tensor(np.random.beta(args.mixup, args.mixup, args.batch_size), dtype=torch.float32)

        X = coeffs.view(-1, 1, 1, 1) * X + (1 - coeffs.view(-1, 1, 1, 1)) * X[perm,]
        S = coeffs.view(-1, 1) * S + (1 - coeffs.view(-1, 1)) * S[perm,]
        Y = coeffs.view(-1, 1) * Y + (1 - coeffs.view(-1, 1)) * Y[perm,]

    if args.cutmix != 0:
        img_height, img_width = X.size()[2:]
        lambd = np.random.beta(args.cutmix, args.cutmix)
        column = np.random.uniform(0, img_width)
        row = np.random.uniform(0, img_height)
        height = (1 - lambd) ** 0.5 * img_height
        width = (1 - lambd) ** 0.5 * img_width
        r1 = round(max(0, row - height / 2))
        r2 = round(min(img_height, row + height / 2))
        c1 = round(max(0, column - width / 2))
        c2 = round(min(img_width, column + width / 2))
        if r1 < r2 and c1 < c2:
            X[:, :, r1:r2, c1:c2] = X[perm, :, r1:r2, c1:c2]

            lambd = 1 - (r2 - r1) * (c2 - c1) / (img_height * img_width)
            S = S * lambd + S[perm] * (1 - lambd)
            Y = Y * lambd + Y[perm] * (1 - lambd)

    return X, S, Y


def train(args, model):
    train_loader, val_loader = get_train_val_loader(args)
    optimizer = torch.optim.Adam(model.parameters(), lr=0, weight_decay=args.wd)

    model, optimizer = amp.initialize(model, optimizer, opt_level='O1')

    if args.load is not None:
        best_acc = score(args, model, val_loader)
    else:
        best_acc = float('-inf')

    if args.mode == 'val':
        return

    if args.pl_epoch is not None:
        test_loader = get_test_loader(args, exclude_leak=True)
        pl_data = set()

    for epoch in range(args.start_epoch, args.epochs):
        with torch.no_grad():
            avg_norm = np.mean([v.norm().item() for v in model.parameters()])

        logging.info('Train: epoch {}   avg_norm: {}'.format(epoch, avg_norm))

        model.train()
        optimizer.zero_grad()

        cum_loss = 0
        cum_acc = 0
        cum_count = 0
        tic = time.time()
        for i, (X, S, _, Y) in enumerate(train_loader):
            lr = get_learning_rate(args, epoch + i / len(train_loader))
            for g in optimizer.param_groups:
                g['lr'] = lr

            if args.cuda:
                X = X.cuda()
                S = S.cuda()
                Y = Y.cuda()
            X, S, Y = transform_input(args, X, S, Y)

            loss, acc = model.train_forward(X, S, Y)
            with amp.scale_loss(loss, optimizer) as scaled_loss:
                 scaled_loss.backward()
            #loss.backward()
            if (i + 1) % args.gradient_accumulation == 0:
                optimizer.step()
                optimizer.zero_grad()

            cum_count += 1
            cum_loss += loss.item()
            cum_acc += acc
            if (i + 1) % args.disp_batches == 0:
                logging.info('Epoch: {:3d} Iter: {:4d}  ->  speed: {:6.1f}   lr: {:.9f}   loss: {:.6f}   acc: {:.6f}'.format(
                    epoch, i + 1, cum_count * args.batch_size / (time.time() - tic), optimizer.param_groups[0]['lr'],
                    cum_loss / cum_count, cum_acc / cum_count))
                cum_loss = 0
                cum_acc = 0
                cum_count = 0
                tic = time.time()

        acc = score(args, model, val_loader)
        torch.save(model.state_dict(), str(args.save + '.{}'.format(epoch)))
        if acc >= best_acc:
            best_acc = acc
            logging.info('Saving best to {} with score {}'.format(args.save, best_acc))
            torch.save(model.state_dict(), str(args.save))


if __name__ == '__main__':
    class MyClass:
        mode = 'train'
        backbone = 'mem-densenet161'
        concat_cell_type = True
        metric_loss_coeff = 0.2
        embedding_size=1024
        bn_mom=0.05
        weight_decay=1e-5
        label_smoothing=0
        mixup=0
        cutmix=1
        classes=1139
        fp16=True
        disp_batches=50
        tta=0
        tta_size=1
        load=None
        start_epoch=0
        pw_aug=(0.1, 0.1)
        scale_aug=0.5
        all_controls_train=True
        data_normalization='sample'
        data = ('C:/Temp')
        cvnumber=0
        data_split_seed=0
        num_data_workers=1
        pl_size_func='x*0.6+0.4'
        batch_size=24
        epochs=90
        lr=('cosine', [1.5e-4])
        seed=42
        head_hidden=None
        cv_number=1
        wd=1e-5
        pl_epoch=None
        gradient_accumulation=2
        cuda=True
    args = MyClass()
    head = '{asctime}:{levelname}: {message}'
    handlers = [logging.StreamHandler(sys.stderr)]
    handlers.append(logging.FileHandler('cellular.log', mode='w'))
    logging.basicConfig(level=logging.DEBUG, format=head, style='{', handlers=handlers)
    logging.info('Start with arguments {}'.format(args))
    setup_determinism(args)
    if args.cuda:
        model = ModelAndLoss(args).cuda()
    else:
        model = ModelAndLoss(args)
    logging.info('Model:\n{}'.format(str(model)))
    if args.load is not None:
        logging.info('Loading model from {}'.format(args.load))
        model.load_state_dict(torch.load(str(args.load)))
    if args.mode == 'train':
        train(args, model)
    elif args.mode == 'predict':
        predict(args, model)
